#! /usr/bin/env python3
# -*- coding: utf-8 -*-
#

import sys, os
from subprocess import call
import time
import ftrobopy
from TouchStyle import *
from TxtStyle import *
from TouchAuxiliary import *

class FtcGuiApplication(TouchApplication):
    def __init__(self, args):
        TouchApplication.__init__(self, args)

        # create the empty main window
        w = TxtWindow("Autostart")
        
        self.vbox = QVBoxLayout()
        #________________________ Anfang

        
            
        bt = QPushButton("Herunterfahren")
        bt.clicked.connect(self.her)
        self.vbox.addWidget(bt)
        
        llb = QLabel("Zeit einstellen:")
        self.vbox.addWidget(llb)
        
        self.input = QLineEdit()
        self.vbox.addWidget(self.input)
        
        auto = QPushButton("fertig!")
        auto.clicked.connect(self.autostart)
        self.vbox.addWidget(auto)
        
        
  
        #_________________________ Ende
        w.centralWidget.setLayout(self.vbox)
        
        

        w.show()
        self.exec_()
        
    
    def her(self):
        call(["sudo", "poweroff"])
        
    def autostart(self):
        timee = self.input.text()
        f = open('/sys/class/rtc/rtc1/since_epoch',"r")
        jetzt = f.read()
        try:
            gleich = int(jetzt) + int(timee)
            print("jetzt ist es:", jetzt)
            print("Wenn ich wieder an gehe ist es:", gleich)


            call(["sudo", "chmod", "a+w", "/sys/class/rtc/rtc1/wakealarm"])
            wake = open('/sys/class/rtc/rtc1/wakealarm',"a")
            wake.write(str(gleich))
            wake.close()
        except:
            print("Keine Zahl!")
    	
 
if __name__ == "__main__":
    FtcGuiApplication(sys.argv)

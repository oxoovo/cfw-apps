#! /usr/bin/env python3
# -*- coding: utf-8 -*-
#

# TODO: Add kinetic scrolling
# http://blog.codeimproved.net/posts/kinetic-scrolling.html

import sys
import subprocess
import stat
import json
from time import sleep
from TouchStyle import *
from os import system

LOCAL_PATH = "/opt/ftc/apps/user/ad5e0ea4-4606-4254-add6-60c452c3db36/"
JSON_PATH = os.path.join(LOCAL_PATH, 'stations.json')

class StationListWidget(QListWidget):
    play = pyqtSignal(str)

    def __init__(self, parent=None):
        super(StationListWidget, self).__init__(parent)
        self.file = open(JSON_PATH)
        self.stations = json.load(self.file)
        self.proc_mpg123 = None
        self.proc_txt_snd_cat = None

        for station, url in sorted(self.stations.items()):
            item = QListWidgetItem(station)
            item.setData(Qt.UserRole, (station, url))
            self.addItem(item)

        self.itemClicked.connect(self.onItemClicked)

    def onItemClicked(self, item):
        system("pidof mpg123 | xargs kill -9")
        sleep(5)
        station, url = item.data(Qt.UserRole)
        cmd = "mpg123 -q --stdout --encoding u8 --rate 22050 --mono -@ ",url," | /opt/ftc/apps/user/ad5e0ea4-4606-4254-add6-60c452c3db36/txt_snd_cat &"
        ccmd = str(cmd).replace(",", "")
        cccmd = str(ccmd).replace("'", "")
        ccccmd = str(cccmd).replace("(", "")
        cccccmd = str(ccccmd).replace(")", "")
        system(str(cccccmd))
        #print(cccccmd)

class FtcGuiApplication(TouchApplication):

    def __init__(self, args):
        TouchApplication.__init__(self, args)

        # create the empty main window
        self.w = TouchWindow("Radio")

        self.vbox = QVBoxLayout()

        self.songlist = StationListWidget(self.w)
        self.songlist.play[str].connect(self.play)
        self.vbox.addWidget(self.songlist)

        """
        self.playing = QLabel()
        self.playing.setText('No Stream')
        self.playing.setStyleSheet('color: yellow')
        self.playing.setAlignment(Qt.AlignCenter)
        self.vbox.addWidget(self.playing)
        """
        self.stop_but = QPushButton("Stop")
        self.stop_but.setDisabled(False)
        self.stop_but.clicked.connect(self.stop)
        self.vbox.addWidget(self.stop_but)
        
        self.w.centralWidget.setLayout(self.vbox)

        self.w.show()

        self.exec_()
        
    def stop(self):
        system("pidof mpg123 | xargs kill -9")

    def play(self, data):
        """
        if data == None:
            self.stop_but.setEnabled(False)
            self.playing.setText('No Stream')
            self.playing.self.playing.setStyleSheet('color: yellow')
        else:
            self.stop_but.setEnabled(True)
            self.playing.setText(data)
            self.playing.setStyleSheet('color: #00ff00')
        """
        pass

if __name__ == "__main__":
    FtcGuiApplication(sys.argv)

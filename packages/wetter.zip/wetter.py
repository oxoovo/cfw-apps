#! /usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import urllib.request, json
from TouchStyle import *
    
class FtcGuiApplication(TouchApplication):
    def __init__(self, args):
        TouchApplication.__init__(self, args)
        
        self.w = TouchWindow("Wetter")
        vbox = QVBoxLayout()
        
        raw_data = urllib.request.urlopen("http://api.openweathermap.org/data/2.5/weather?q=wiesbaden&APPID=89b8070465d1e9f42f052792440f2bc0").read().decode()  # download release api data
        WeatherData = json.loads(raw_data)
        
        a = "Luftfeuchtigkeit: {}%".format(WeatherData["main"]["humidity"]) + "\n"
        b = "Luftdruck: {} hpa".format(WeatherData["main"]["pressure"]) + "\n"
        c = "Temperatur: {}° C".format(str(WeatherData["main"]["temp"] - 273)) + "\n"
        d = "Max. Temperatur: {}° C".format(str(WeatherData["main"]["temp_max"] - 273)) + "\n"
        e = "Min. Temperatur: {}° C".format(str(WeatherData["main"]["temp_min"] - 273)) + "\n"
        f = "Windgeschwindigkeit: {} m/s".format(WeatherData["wind"]["speed"]) + "\n"
        g = "Windrichtung: {}°".format(WeatherData["wind"]["deg"]) + "\n"
        h = "Wetter: {}".format(WeatherData["weather"][0]["description"]) + "\n"
        
        text = a + b + c + d + e + f + g + h
        print(text)
        
        t = QTextEdit()
        t.setText(text)
        vbox.addWidget(t)
        
        self.w.centralWidget.setLayout(vbox)

        
        self.w.show() 
        self.exec_()
        
if __name__ == "__main__":
    FtcGuiApplication(sys.argv)
